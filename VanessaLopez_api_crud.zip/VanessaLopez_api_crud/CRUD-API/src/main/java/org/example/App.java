package org.example;

import com.hellokaton.blade.Blade;

public class App {
    public static void main(String[] args) {
        Blade.create().start();
    }
}
